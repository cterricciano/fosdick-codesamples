﻿using System;
using System.Text;
using System.Windows.Forms;


namespace encryption_tester
{
    public partial class DemoForm : Form
    {
        private void encrypt_Click(object sender, EventArgs e)
        {
            var pem_public_key = TokenExRSA.ReadAsymmetricKeyParameter(txtPEMFile.Text);
            string CCNUM = txtccnum.Text;
            string encrypted = TokenExRSA.RSAEncryptToBase64(pem_public_key, CCNUM);
            txtenc.Text = encrypted;
            
        }
 
        public DemoForm()
        {
            InitializeComponent();
        }

        private void DemoForm_Load(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "PEM files|*.pem";
            openFileDialog1.ShowDialog();
            txtPEMFile.Text = openFileDialog1.FileName;
        }
    }
}
