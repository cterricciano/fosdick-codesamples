For documentation and mailing lists, see the project web site: http://www.bouncycastle.org/csharp/

Contact me directly for package/build issues: www.soygul.com/contact

� 2015, Bouncy Castle Project